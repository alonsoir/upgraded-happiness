"""Protocols package - Network event protocols"""

# Importar solo lo que existe
from .protobuf import network_event_pb2

__all__ = ["network_event_pb2"]
